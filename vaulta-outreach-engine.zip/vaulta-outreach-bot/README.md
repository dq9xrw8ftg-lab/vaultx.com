# VAULTA Outreach Engine — starter build

A Next.js starter for one shared investor-lead pipeline across Farcaster, Discord and Telegram. Includes a dashboard, Prisma/PostgreSQL schema, authenticated lead/campaign APIs, health endpoint, and an opt-in Telegram webhook. **It is not yet a live, fully integrated or deployed bot.** Farcaster and Discord require a selected provider/API, credentials, platform authorization, and implementation/testing against that provider's current API.

## What is implemented
- Responsive dark-green VAULTA outreach dashboard.
- Shared lead, campaign and activity data model in Prisma.
- Admin-token-protected lead and campaign API routes.
- Telegram webhook that responds only after a user starts/messages the bot, shares the public contract reference and risk disclosure, and offers opt-out.
- Human approval status for campaigns; no automatic bulk messaging.
- Environment variable template and Vercel-friendly Next.js structure.

## What is intentionally not implemented
- No scraping private member lists, unsolicited DMs, automatic joining of users, fake accounts, fake buyers, wash trading, or token-price manipulation.
- No live Farcaster publish adapter yet. Choose a currently supported provider/API, create authorized credentials, then implement and test its exact API contract.
- No live Discord interaction handler yet. Create an app in the Discord Developer Portal, install it only in a server you manage, define permitted commands, and implement Discord's request-signature verification before exposing an interaction endpoint.
- No purchase execution, wallet custody, or trading automation.
- No production deployment has been performed from this package.

## Requirements
- Node.js 20.9+ recommended
- PostgreSQL database
- Telegram bot token from BotFather (optional until Telegram setup)
- Vercel account or another Next.js host

## Local setup
1. Copy `.env.example` to `.env.local`.
2. Set `DATABASE_URL` and a long random `ADMIN_API_TOKEN`.
3. Install dependencies: `npm install`.
4. Generate Prisma client: `npm run db:generate`.
5. Apply schema: `npm run db:push`.
6. Start: `npm run dev`.
7. Open `http://localhost:3000`.

For a clean production database, review the schema and use a migration workflow rather than relying indefinitely on `db push`.

## Telegram setup
1. Create a bot through Telegram's official BotFather and store its token only in the server environment.
2. Set `TELEGRAM_WEBHOOK_SECRET` to a long random string and set `TELEGRAM_BOT_TOKEN`.
3. Deploy the app over HTTPS.
4. Register the webhook (replace placeholders locally; do not publish the token):

```bash
curl -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook" \
  -H 'content-type: application/json' \
  -d '{"url":"https://YOUR_DEPLOYMENT_DOMAIN/api/telegram/webhook","secret_token":"YOUR_TELEGRAM_WEBHOOK_SECRET"}'
```

Telegram requires the webhook `secret_token` to contain allowed characters and be 1–256 characters. Keep the value private. This handler checks the `X-Telegram-Bot-Api-Secret-Token` header.

## Vercel deployment
1. Put this folder in a private GitHub repository and import it into Vercel.
2. Provision PostgreSQL and add `DATABASE_URL` to Vercel project environment variables.
3. Set `ADMIN_API_TOKEN` and optional Telegram variables in Vercel; never commit secrets.
4. Deploy. Run Prisma client generation during install/build. Apply database schema via a controlled migration step.
5. Configure Telegram webhook after the HTTPS deployment is live.
6. Keep `FARCASTER_ENABLED=false` and `DISCORD_ENABLED=false` until those adapters are implemented, authorized and tested.

## API quick reference
All admin APIs require `Authorization: Bearer $ADMIN_API_TOKEN`.

- `GET /api/health` — safe service/configuration status (does not expose credentials).
- `GET /api/leads` — list up to 250 leads.
- `POST /api/leads` — create a lead.
- `GET /api/campaigns` — list campaigns.
- `POST /api/campaigns` — save a campaign as `PENDING_APPROVAL`; this does not send messages.

Example campaign body:

```json
{
  "name": "Base ecosystem project review",
  "channel": "FARCASTER",
  "messageTemplate": "Hello — we're sharing VAULTA (VLX) on Base and seeking independent technical feedback. Contract: ... Please review all risks independently; no returns are guaranteed.",
  "audienceDescription": "People who publicly discuss Base and DeFi and permit project introductions"
}
```

## Important before outreach
- Confirm legal authorization and disclosure obligations for public investment promotion in each target jurisdiction, including Nigeria.
- Do not claim that VLX is liquid, currently swappable, audited, or verified unless supported by current evidence.
- The 100-investor figure is a goal, not a guarantee. Count buyers only when a genuine transaction is independently verifiable.
- Provide opt-out mechanisms, respect platform policies and applicable privacy laws, and obtain consent where required.
- Do not put private keys, seed phrases, wallet recovery phrases, or API secrets in the app UI, chat, Git, or browser code.
