import { NextRequest, NextResponse } from 'next/server';
export function requireAdmin(request: NextRequest): NextResponse | null {
  const expected = process.env.ADMIN_API_TOKEN;
  if (!expected) return NextResponse.json({ error: 'Server is not configured: ADMIN_API_TOKEN is missing.' }, { status: 503 });
  const supplied = request.headers.get('authorization')?.replace(/^Bearer\s+/i, '');
  if (!supplied || supplied !== expected) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  return null;
}
export function safeEqual(a: string, b: string) {
  if (a.length !== b.length) return false;
  let out = 0;
  for (let i = 0; i < a.length; i++) out |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return out === 0;
}
