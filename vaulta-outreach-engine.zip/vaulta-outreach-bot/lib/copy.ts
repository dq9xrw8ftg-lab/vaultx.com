export const PROJECT_FACTS = {
  name: 'VAULTA',
  token: 'VLX',
  network: 'Base Mainnet',
  contract: '0x8A1D4f41c20662b64b5b9a649DBDfF4024c5d1AF',
  explorer: 'https://basescan.org/address/0x8A1D4f41c20662b64b5b9a649DBDfF4024c5d1AF',
};
export const REVIEW_MESSAGE = `Hello — I’m sharing VAULTA (VLX), a project building around crypto and real-world-asset concepts on Base. Token contract: ${PROJECT_FACTS.contract}. We’re seeking independent technical feedback on the contract, market availability, and marketplace experience. Please review the public evidence and risks independently; this is not a promise of returns or a claim that liquidity/trading has been verified. Contract: ${PROJECT_FACTS.explorer}. If you’d like further details, reply and I’ll share the project documentation.`;
export const BOT_WELCOME = `Welcome to VAULTA information. I can share the public VLX contract and project updates. Crypto tokens are risky and you may lose your entire purchase. No returns are guaranteed. Please review the contract independently: ${PROJECT_FACTS.explorer}\n\nChoose “Project info” or “Opt out”.`;
