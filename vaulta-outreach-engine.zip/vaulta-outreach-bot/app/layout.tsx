import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'VAULTA Outreach Engine', description: 'Consent-based investor outreach and community dashboard for VAULTA.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
