import { NextResponse } from 'next/server';
export async function GET(){return NextResponse.json({ok:true,service:'vaulta-outreach-engine',databaseConfigured:Boolean(process.env.DATABASE_URL),telegramConfigured:Boolean(process.env.TELEGRAM_BOT_TOKEN),farcasterConfigured:process.env.FARCASTER_ENABLED==='true',discordConfigured:process.env.DISCORD_ENABLED==='true'});}
