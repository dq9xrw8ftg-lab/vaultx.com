# Handoff notes for the VLX pool review

Known token address supplied by project owner: `0x8A1D4f41c20662b64b5b9a649DBDfF4024c5d1AF` on Base Mainnet.

When the pool information is available, record:
- DEX and pool URL/address
- token pair and fee tier (if Uniswap v3)
- token0/token1 and decimals
- active liquidity / reserves and current price
- pool creation transaction and timestamp
- whether the quote route exists for VLX -> WETH/USDC and reverse
- estimated price impact for small test amounts (read-only quote first)
- whether token approvals and swap transaction simulations succeed
- verified buy/sell execution evidence, if any
- who controls LP positions and whether liquidity can be withdrawn

A token page or LP position display is not proof that buyers can execute a swap. Do not submit a transaction just to test a route unless the wallet owner understands and approves the exact network, tokens, amount, fees, slippage and risk.
