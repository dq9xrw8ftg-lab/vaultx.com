# vaultx
VaultX — a crypto platform project for wallet integrations, digital-asset information, purchasing flows, and secure web application infrastructure.
