# Deploy Vaulta prototype

Upload the contents of this directory to a static host (Cloudflare Pages, a static web server, or another supported host). Keep all HTML files and CSS together at the same path. If using Cloudflare Pages, create or select a Pages project, upload/connect the site directory, and confirm the production domain after deployment.

This package has not been deployed by this script. Do not use the prototype to collect real deposits or card details. Production requires a backend, authentication, database, payment and custody integrations, security review, legal/regulatory review, and independent verification of asset data.


## Exchange-inspired preview update
Upload the full extracted folder as a static site. Ensure all HTML, CSS and JS files are uploaded together. Start with `index.html`; the new pages are `markets.html`, `trade.html`, and `academy.html`. The dark charcoal/yellow styling is Vaulta's own implementation inspired by familiar crypto exchange UX, not Binance branding or affiliation. Market data and order book values are illustrative placeholders. Do not connect real trading or customer funds until authentication, key management, risk controls, compliance, audit logs and vetted providers are implemented.
