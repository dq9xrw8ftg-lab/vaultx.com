/* Vaulta interactive preview layer. Market values below are clearly illustrative demo data. */
(()=>{
 const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
 const toast=(msg)=>{let t=$('.vaulta-toast');if(!t){t=document.createElement('div');t.className='vaulta-toast';t.setAttribute('role','status');document.body.append(t)}t.textContent=msg;t.classList.add('show');clearTimeout(window.__vt);window.__vt=setTimeout(()=>t.classList.remove('show'),2800)};
 // Persistent top scroll progress.
 const bar=document.createElement('div');bar.className='vaulta-progress';document.body.prepend(bar);
 const progress=()=>{const d=document.documentElement;bar.style.width=(d.scrollHeight-d.clientHeight?d.scrollTop/(d.scrollHeight-d.clientHeight)*100:0)+'%'};
 window.addEventListener('scroll',progress,{passive:true});progress();
 // Add a market ticker to each page without replacing existing page content.
 const nav=$('.nav');
 if(nav&&!$('.vaulta-ticker')){
  const ticker=document.createElement('div');ticker.className='vaulta-ticker';ticker.setAttribute('aria-label','Illustrative market ticker');
  ticker.innerHTML='<span class="ticker-label">MARKET WATCH · DEMO</span><span class="ticker-item">BTC/USDT <b>$67,420.10</b> <span class="ticker-change">+1.42%</span></span><span class="ticker-item">ETH/USDT <b>$2,481.30</b> <span class="ticker-change">+0.86%</span></span><span class="ticker-item">BNB/USDT <b>$612.80</b> <span class="ticker-change">+0.38%</span></span><span class="ticker-item">SOL/USDT <b>$142.65</b> <span class="ticker-down">−0.24%</span></span><span class="sim-note">Illustrative prices, not live quotes.</span>';
  nav.insertAdjacentElement('afterend',ticker);
 }
 // Reveal content on scroll, while respecting reduced-motion settings.
 const revealCandidates=$$('main section,main article,.feature-card,.asset-card,.plan-card,.summary-tile,.hero-card');
 revealCandidates.forEach((el,i)=>{if(i>0)el.classList.add('reveal')});
 if('IntersectionObserver' in window&&!matchMedia('(prefers-reduced-motion: reduce)').matches){
  document.body.classList.add('reveal-ready');
  const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('is-visible');io.unobserve(e.target)}}),{threshold:.08});
  $$('.reveal').forEach(el=>io.observe(el));
 }else $$('.reveal').forEach(el=>el.classList.add('is-visible'));
 // Floating top button.
 const top=document.createElement('button');top.type='button';top.className='vaulta-top';top.textContent='↑';top.setAttribute('aria-label','Back to top');top.style.cssText='position:fixed;right:20px;bottom:20px;z-index:80;width:44px;height:44px;border-radius:50%;border:1px solid #f0b90b;background:#f0b90b;color:#111;font-size:23px;font-weight:800;box-shadow:0 8px 30px #0008;cursor:pointer;opacity:0;pointer-events:none;transition:opacity .2s';
 document.body.append(top);window.addEventListener('scroll',()=>{top.style.opacity=scrollY>450?'1':'0';top.style.pointerEvents=scrollY>450?'auto':'none'},{passive:true});top.onclick=()=>scrollTo({top:0,behavior:'smooth'});
 // Demo-only action notices; don't misrepresent a connected exchange or wallet.
 $$('button').forEach(b=>{if(b.id==='connect'||b.classList.contains('vaulta-top')||b.dataset.vaultaBound)return;b.addEventListener('click',()=>{if(b.closest('[data-interactive-demo]'))return;const label=(b.textContent||'').trim().toLowerCase();if(/deposit|withdraw|invest|activate|connect wallet|wallet|claim reward|request delivery|sign in|create account|place order|buy crypto|sell crypto/.test(label)){toast('Preview mode: connect verified services before using this feature with real funds.')}})});
 // Watchlist buttons on the markets page.
 $$('.watch-btn').forEach(b=>b.addEventListener('click',()=>{b.classList.toggle('selected');b.textContent=b.classList.contains('selected')?'★ Saved':'☆ Watch';toast(b.classList.contains('selected')?'Added to this preview watchlist':'Removed from this preview watchlist')}));
 const convert=$('#convertAmount'),from=$('#convertFrom'),toCoin=$('#convertTo'),result=$('#convertResult');
 if(convert&&from&&toCoin&&result){
  const rates={USDT:1,BTC:67420.1,ETH:2481.3,BNB:612.8,SOL:142.65};
  const calc=()=>{const a=Math.max(0,Number(convert.value)||0),v=a*rates[from.value]/rates[toCoin.value];result.textContent=v.toLocaleString(undefined,{maximumFractionDigits:8})+' '+toCoin.value};
  [convert,from,toCoin].forEach(e=>e.addEventListener('input',calc));calc();
 }
 const calcLoss=$('#lossSlider'),lossOut=$('#lossOut'),capital=$('#capitalInput'),capitalOut=$('#capitalOut');
 if(calcLoss&&lossOut){const run=()=>{const loss=Number(calcLoss.value);lossOut.textContent=loss+'%';const impact=$('#lossImpact');if(impact&&capital)impact.textContent=(Number(capital.value||0)*(1-loss/100)).toLocaleString('en-US',{style:'currency',currency:'USD',maximumFractionDigits:0});};calcLoss.addEventListener('input',run);if(capital)capital.addEventListener('input',run);run();}
 const search=$('#marketSearch');if(search)search.addEventListener('input',()=>{$$('.market-row').forEach(r=>r.hidden=!r.textContent.toLowerCase().includes(search.value.toLowerCase()))});
})();
