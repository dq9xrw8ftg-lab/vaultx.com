# Vaulta website prototype — modified cumulative edition

## Pages retained from the existing package
- `index.html` — homepage and platform overview
- `assets.html` — 60 illustrative real-world asset concepts and market quote panel
- `plans.html` / `plan-detail.html` — 12 illustrative capital tiers and plan details
- `investment.html` — asset dossier pages
- `dashboard.html` — investor workflow previews and contribution planner
- `exchanges.html` — exchange directory with 100+ external links in the existing source
- `admin.html` — admin interface prototype

## Added in this edition
- `signal-lab.html` — fee-aware spread calculator and signal due-diligence checklist
- `referral.html` — proposed 7% referral and $70 onboarding incentive disclosure / preview
- `risk-center.html` — due diligence education and interactive checklist
- Midnight indigo, violet, cyan and warm-gold design refresh
- Scroll progress bar, reveal-on-scroll transitions, animated hero rings, scroll cue and back-to-top control
- Responsive layouts and reduced-motion accessibility handling

## Run locally
Open `index.html` or serve this directory with a static web server.

## Important prototype boundaries
This is a front-end prototype. It does not provide authenticated accounts, live investment execution, payment settlement, custody, real referral rewards, real contract activation or actual profit distributions. Connect a secure backend, audited database, identity and compliance provider, contracted market-data feeds, secure payment providers and appropriate legal/regulatory operations before accepting real funds. The $20,000 / 1-year, $50,000 / 2-year and $100,000+ / 5-year contract concepts, $70 incentive and 7% referral programme are proposals requiring final legal terms and eligibility rules. Do not advertise guaranteed returns.


## Binance-inspired exchange UI update
- `binance-inspired.css` introduces a dark charcoal + signal-yellow theme inspired by common crypto exchange interfaces. Vaulta is independent and is not affiliated with Binance.
- `markets.html` adds searchable demo market rows, watchlist toggles, an illustrative market chart and a conversion calculator.
- `trade.html` adds a paper-order ticket, value calculator, order-book mockup and clear non-live status.
- `academy.html` adds learning tracks and an interactive knowledge check.
- Shared JavaScript adds an illustrative market ticker, scroll progress, scroll reveals, back-to-top, watchlist controls and demo-only calculations.
- Market numbers are static illustrative placeholders, not live prices. No wallet, trading, deposit or withdrawal services are connected.
