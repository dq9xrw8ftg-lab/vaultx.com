VAULTA ENHANCED STATIC WEBSITE

Upload the extracted folder to your static host with index.html at the root.
Pages: /, /assets.html, /plans.html, /investment.html, /plan-detail.html, /dashboard.html, /exchanges.html, /admin.html

Included: 60 illustrative asset cards with real stock-photo URLs; reference values and scale; a CoinGecko public API attempt for four cryptocurrency quotes refreshing every 60 seconds; searchable exchange/provider directory; dashboard purchase preview and recurring contribution preview.

IMPORTANT LIMITATIONS
- Real-world asset prices, values, quantities and examples are illustrative and not verified offers or live appraisals.
- Crypto market data depends on a public third-party API and can be rate-limited or unavailable. Production live market service requires licensed/contracted data feeds and backend caching/monitoring.
- Exchange directory links are not endorsements; availability, licensing and terms must be verified for each country.
- No genuine investor reviews are fabricated. Add real, consented, auditable reviews only.
- Dashboard actions are demonstrations; no funds move and no orders/payment mandates are created.
- Never store raw card numbers or CVV. Production recurring payments require PCI-compliant hosted checkout/tokenization, a secure backend, consent records, cancellation and refund workflows.
- Production investing requires legal/regulatory review, real asset custody/ownership evidence, KYC/AML, security testing, monitoring and secure authenticated backend services.
